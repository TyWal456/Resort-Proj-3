/***************************************************************************************************************************/
/*Name: Tyrell Walrond
Instructor: Professor DeMarco
Course: CSC 243-010
filename: Rent.java
Due Dates: Sprint 1 --> 10/12/18; Sprint 2 --> 10/26/18; Sprint 3 --> 11/09/18
Program Purpose: The purpose of this class file is to be able to document and properly define 
                        utility functions in order to drive the user implementation file for renting camping equipment.
Time Spent on Program: 2 weeks, 3 days, 4 hours
*/
/********************************************************************************************************************************/



/***********************************************/
/***********************************************************/
/*NOTE TO SELF: FIX EQUIPMENT PRICES IN SET() FUNCTIONS BELOW AND DEBUG ANY 
EQUATIONS BY RUNNING IN JVM IN PUTTY...*/

// rentPack compilation java executable package...
//package rentPack;

//java utility imports...
package rentPack;
import java.util.*;
import java.lang.*;

//Rent
public class Rent{ 
    Scanner in = new Scanner(System.in);
	public static String custName;
    public static String phone;
    public static String email;

    // I moved these to Rent, since an object can't include an array of itself, I think.
    //  Even if it could, I wouldn't vouch for it! :P
    public static ArrayList<RentObj> rentals = new ArrayList<>();
	public static ArrayList<RentObj> boats = new ArrayList<>(); 
	public static ArrayList<RentObj> chairs = new ArrayList<>();
	public static ArrayList<RentObj> umbrellas = new ArrayList<>();

	Rent(String name, String phone, String email) {
		setName(name);
		setPhone(phone);
		setEmail(email);
	}
    
    Rent(){
    	contactInfo();
    }
    
    public void setName(String custName){
            this.custName = custName;
    }
    public String getName(){
            return custName;
    }
    public void setEmail(String email){
            this.email = email;
    }
    public String getEmail(){
            return email;
    }
            
    public void setPhone(String phone){
            this.phone = phone;
    }
   public String getPhone(){
            return phone;
    }
    public void contactInfo(){
        System.out.println("Enter full name: \t");
        custName=in.nextLine();
        setName(custName);
        
        
        System.out.println("Enter your email address: \t");
        email=in.next();
        setEmail(email);
        
        
        System.out.println("Enter your phone number: \t");
        phone=in.next();
        setPhone(phone);
             
            
    }

    public void getContactInfo(){
            System.out.println("Hello " + getName() +'\n');
            System.out.println("Your telephone is: " + getPhone()+ '\n');
            System.out.println("Your email address is: "+ getEmail() + '\n');
    }
	
	public void printRentals(){
		for(int i = 0; i< rentals.size(); i++){
			System.out.println(rentals.get(i).getEquipType() + ", " + rentals.get(i).getEquipName() + ", " + rentals.get(i).getPrice() + ", " + rentals.get(i).getRentDays()
						+ ", " + rentals.get(i).getTotalCost() + ", " + rentals.get(i).getDate());
		}
			
	}

	public static void addEquipment()
	{
           Scanner in = new Scanner(System.in);

                char options = ' ';
                RentObj myBoat = new RentObj();
                RentObj myChair = new RentObj();
                RentObj myUmbrella = new RentObj();
				RentObj overallSum = new RentObj();
                
                System.out.println("    Welcome to Victoria's Vacation Rental Shack!    ");
                System.out.println("What would you like to rent with us today?: \n");
                System.out.println("a. Boats   " + "b. Chairs   " + "c. Umbrellas   ");
                options = in.next().charAt(0);
                
        
                switch(options){
                        
                        case 'a': 
                                
                                myBoat.Boats();
                                 System.out.println("                                      ORDER INVOICE                                                   ");
                                 System.out.println("___________________________________________________________________________________");
                                 System.out.println("Type  |"  +"Equip Name   |" + "Price   |" + "# Of Rent Days   |"+ "Total Cost w/ Shipping/Handling"); 
                                 boats.add(myBoat);
                        break;
                        case 'b':
                                myChair.Chairs();
                                System.out.println("                                      ORDER INVOICE                                                   ");
                                 System.out.println("_____________________________________________________________________________________");
                                 System.out.println("Type  |"  +"Equip Name   |" + "Price   |" + "# Of Rent Days   |"+ "Total Cost w/ Shipping/Handling"); 
                                 chairs.add(myChair);
                         break;
                         case 'c':
                                myUmbrella.Umbrellas();
                                System.out.println("                                      ORDER INVOICE                                                   ");
                                 System.out.println("_______________________________________________________________________________________");
                                 System.out.println("Type  |"  +"Equip Name   |" + "Price   |" + "# Of Rent Days   |"+ "Total Cost w/ Shipping/Handling"); 
                                 umbrellas.add(myUmbrella);
                
              }
			 
        }
	
}   
        
        



class RentObj{
    Scanner in = new Scanner(System.in);
    public static String equipType = " ";
    public static String equipName = " ";
    public static float totalCharge;
    public static int numDays;
    public static String date;
    public static final double SALES_TAX = 0.06;
    public static float deliveryCharge;
    public static float charge_per_item;
    public char choice = ' ';
    public int typeChoice;
    public char delivLoc = ' ';
	public static int number;
	public float subTotal = 0;
	public float totalSum = 0;
        
	
	RentObj(){}
	
    RentObj(String eqType, String eqName, float eqPrice, int eqNum, int eqRdays, String eqRdate){
        equipType = eqType;
        equipName = eqName;
        charge_per_item = eqPrice;
        numDays = eqRdays;
        date = eqRdate;
        number = eqNum;
    }                

                                    
                                    
    public void setPrice(float charge_per_item){
            this.charge_per_item = charge_per_item;
    }
            
    public static float getPrice(){
            return charge_per_item;
    }
    public void setRentDays(int numDays){
            this.numDays = numDays;
    }
    public static int getRentDays(){
            return numDays;
    }
            
    public void setAmount(int number){
            this.number = number;
    }
    public static int getAmount(){
            return number;
    }
    public void setTotalCost(float totalCharge){
            this.totalCharge = totalCharge;
    }
            
    public static float getTotalCost(){
            return totalCharge;
    }
    public void setDate(String date){
            this.date = date;
    }
    public static String getDate(){
            return date;
    }
            
            
    public void setEquipType(String equipType){
            this.equipType = equipType;
    }
    public static String getEquipType(){
            return equipType;
    }
            
    public void setEquipName(String equipName){
            this.equipName = equipName;
    }
    
    public static String getEquipName(){
            return equipName;
    }

	public void setOverallSum(float totalSum){
		this.totalSum = totalSum;
	}
	public float getOverallSum(){
		return totalSum;
	}

	


public void Boats(){
	float tCostArr[] = new float[4];
        float priceArr[] = new float[4];
        int rentDayArr[] = new int[4];
        String typeArr[] = new String[4];
        
	
        setEquipType("Boat");
	
	System.out.println("What type of Boat(s) will you be renting? :");
    System.out.println("1. Paddle Board - Price: $65.00 " + '\n' + "2. Single Kyack - Price: $45.00 " + '\n' + "3. Tandem Kyack - Price: $65.00  " + '\n' + "4. Canoe - Price: $75.00 ");
    typeChoice = in.nextInt();


    System.out.println("How many of these boat types are you renting?: ");
    number = in.nextInt();
    
    System.out.println("How many days will you be renting with us?: ");
    numDays = in.nextInt();
    
    System.out.println("Where will this(these) item(s) be delivered?: ");
    System.out.println("a. Vacation Venue" + '\n' + "b. Bella's Beach" + '\n' + "c. Griffin's Grove");
    delivLoc = in.next().charAt(0);
                    
                
    switch(typeChoice){
	    case 1:
                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                           
			this.setPrice(65);
                        this.setEquipName("Paddle Board");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " +"$"+ priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
									totalSum+= tCostArr[c];
                        }
                }
					
    }                
					
						
	
           for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(65);
                        this.setEquipName("Paddle Board");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
                        }
                }   
    }                
                            
            for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(65);
                        this.setEquipName("Paddle Board");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal+20);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
								totalSum+= tCostArr[c];
                        }
                }   
    }                
			                                      
			break;
                                      
                            
        case 2:
            for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(45);
                        this.setEquipName("Single Kyack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
									totalSum+= tCostArr[c];
                        }
                }   
    }                
             for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(45);
                        this.setEquipName("Single Kyack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
									totalSum+= tCostArr[c];
                        }
                }   
    }                
             for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(45);
                        this.setEquipName("Single Kyack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
								totalSum+= tCostArr[c];
                        }
                }   
    }                
                    
			break;

        case 3:
             for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(65);
                        this.setEquipName("Tandem Kyack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
             for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(65);
                        this.setEquipName("Tandem Kyack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
								totalSum+= tCostArr[c];
                        }
                }   
    }                
             for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(65);
                        this.setEquipName("Tandem Kyack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
            break;
        case 4:
             for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(75);
                        this.setEquipName("Canoe");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
            for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(75);
                        this.setEquipName("Canoe");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
                    
            for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(75);
                        this.setEquipName("Canoe");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(numDays >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Boat" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Boat" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
						
                }   
    }                
        
                        }
                                }

	
	


                
                                
                        

                                
                public void Chairs(){
                float tCostArr[] = new float[4];
                float priceArr[] = new float[4];
                int rentDayArr[] = new int[4];
                String typeArr[] = new String[4];
                System.out.println("What type of Chair(s) will you be renting? :");
                System.out.println("1. Sling Low - Price: $5.00 " + '\n' + "2. Chaise Lounge - Price: $7.00 " + '\n' + "3. Folding Classic - Price: $5.00  " + '\n' + "4. Adirondack - Price: $10.00 ");
                typeChoice = in.nextInt();
                                   
                                                        
                System.out.println("How many of these chair types are you renting?: ");
                number = in.nextInt();
                System.out.println("How many days will you be renting with us?: ");
                numDays = in.nextInt();
                System.out.println("Where will this(these) item(s) be delivered?: ");
                System.out.println("a. Vacation Venue" + '\n' + "b. Bella's Beach" + '\n' + "c. Griffin's Grove");
                delivLoc = in.next().charAt(0);
                
               switch(typeChoice){
                       case 1:
               for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(5);
                        this.setEquipName("Sling Low");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(number >= 3)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
                                        for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(5);
                        this.setEquipName("Sling Low");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
                                        for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
			this.setPrice(5);
                        this.setEquipName("Sling Low");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
                                        
                                        break;

                                
                                case 2:
                                for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(7);
                        this.setEquipName("Chaise Lounge");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
    }                
                                       for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(7);
                        this.setEquipName("Chaise Lounge");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                } 
                                       }                
                                        
                                        for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(7);
                        this.setEquipName("Chaise Lounge");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }   
                                        }
                                                                 
                                         break;
                                
                                case 3:
                                        for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(5);
                        this.setEquipName("Folding Classic");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                        }                
                                        
                                         for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(5);
                        this.setEquipName("Folding Classic");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                        for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(5);
                        this.setEquipName("Folding Classic");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                        }                
                                                
                                        
                                        break;
                                
                                case 4:
                                         for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(10);
                        this.setEquipName("Adironack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                       for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(10);
                        this.setEquipName("Adironack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                       }                
                                        
                                        for(int a = 0; a < 1; a++){
                                        for(int b = 0; b < 1; b++){
                                                for(int c = 0; c < 1; c++){
                                                        for(int d = 0; d < 1; d++){
			this.setPrice(10);
                        this.setEquipName("Adironack");
                        typeArr[d] = getEquipName();
			priceArr[a] = getPrice();
                        rentDayArr[b] =  getRentDays();
			if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				if(number >= 4)
				{
					// System.out.println("$" +(float)(getTotalCost()-(getTotalCost()*0.10)));
					totalCharge = (float)(totalCharge - (totalCharge *.10));
                                        tCostArr[c] = getTotalCost();
                                        System.out.println("Chair" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				}
				else
					System.out.println("Chair" + " " + typeArr[d] + " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }               System.out.println("What date is this delivery for: ");
                                        date = in.next();
                                        setDate(date);
                                        }
                                                break;
                                        
                                        
                                        
                                }
                }  
                                
                        
               
                        
                        
                public void Umbrellas(){
                float tCostArr[] = new float[4];
                float priceArr[] = new float[4];
                int rentDayArr[] = new int[4];
                String typeArr[] = new String[4];
                                
                                System.out.println("What type of Umbrella(s) will you be renting? :");
                                System.out.println("1. Chair Side - Price: $5.00 " + '\n' + "2. Single - Price: $10.00 " + '\n' + "3. Family - Price: $15.00  " + '\n' + "4. Tent - Price: $20.00 ");
                                typeChoice = in.nextInt();
                               
                                        
                                System.out.println("How many of these umbrella types are you renting?: ");
                                number = in.nextInt();
                                System.out.println("How many days will you be renting with us?: ");
                                numDays = in.nextInt();
                                System.out.println("Where will this(these) item(s) be delivered?: ");
                                System.out.println("a. Vacation Venue" + '\n' + "b. Bella's Beach" + '\n' + "c. Griffin's Grove");
                                delivLoc = in.next().charAt(0);
         switch(typeChoice){
                 case 1:
                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(5);
                                this.setEquipName("Chair-Side");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                                                                        
                                                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(5);
                                this.setEquipName("Chair-Side");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal+ 10);
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                               for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(5);
                                this.setEquipName("Chair-Side");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                                
                                                
                                                break;
                                      
                                        case 2:
                                                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(10);
                                this.setEquipName("Single");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal);
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                                
                                                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(10);
                                this.setEquipName("Single");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10);
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                                
                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(5);
                                this.setEquipName("Single");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20);
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                                         }                
                                                
                                                break;
                                
                                        case 3:
                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(15);
                                this.setEquipName("Family");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal );
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                }
                }
                                         
               for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(15);
                                this.setEquipName("Family");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10 );
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                        }
               }
                                                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(15);
                                this.setEquipName("Family");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20 );
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                        }
                                                }
                                                break;
                                
                                        case 4:
                                                for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(20);
                                this.setEquipName("Tent");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'a'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal );
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                        }
                                                }
                                                 for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(20);
                                this.setEquipName("Tent");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'b'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 10 );
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                                }
														totalSum+= tCostArr[c];

                        }
                        }
                                                 }
                                                 for(int a = 0; a < 1; a++){
                        for(int b = 0; b < 1; b++){
                                for(int c = 0; c < 1; c++){
                                        for(int d = 0; d < 1; d++){
                                this.setPrice(20);
                                this.setEquipName("Tent");
                                typeArr[d] = getEquipName();
                                priceArr[a] = getPrice();
                                rentDayArr[b] =  getRentDays();
                                if(delivLoc == 'c'){
                                                  
                                setRentDays(numDays);
				subTotal = getRentDays() * number * getPrice();
				totalCharge = (float)((SALES_TAX * subTotal) + subTotal + 20 );
                                tCostArr[c] =  getTotalCost();
				System.out.println("Umbrella" + " " +typeArr[d]+ " " + priceArr[a] + " " + rentDayArr[b] + " " + tCostArr[c]); 
				
				 
                        }

                          
                                        }
																totalSum+= tCostArr[c];

                                }
                        }
                                                 }

                          System.out.println("What date is this delivery for: ");
                                                        date = in.next();
                                                        setDate(date);
                                                 }
                }
}
                        
                        
                                
                       
                        
        
        

        
        




