package rentPack;
import java.util.*;
import java.lang.*;

public class rentTest{
	
	public static void main(String args[]){
		
		
                
                
                Rent myRental = new Rent();
                
                for(int i = 0; i < 5; i++){
                        myRental.addEquipment();
                        
                }
				
				System.exit(0);
                
                // myRental.getContactInfo();
		// myRental.printRentals();
		
	}
	
}
	